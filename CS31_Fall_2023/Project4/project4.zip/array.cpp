#include <iostream>
#include <string>
#include <cassert>
using namespace std;


int reduplicate(string a[], int n);
int locate(const string a[], int n, string target);
int locationOfMax(const string a[], int n);
int circleLeft(string a[], int n, int pos);
int enumerateRuns(const string a[], int n);
int flip(string a[], int n);
int locateDifference(const string a1[], int n1, const string a2[], int n2);
int subsequence(const string a1[], int n1, const string a2[], int n2);
int locateAny(const string a1[], int n1, const string a2[], int n2);
int divide(string a[], int n, string divider);


int main()
{
    string h[7] = { "nikki", "ron", "asa", "vivek", "", "chris", "donald" };
    assert(locate(h, 7, "chris") == 5);
    assert(locate(h, 7, "asa") == 2);
    assert(locate(h, 2, "asa") == -1);
    assert(locationOfMax(h, 7) == 3);

    string g[4] = { "nikki", "ron", "chris", "tim" };
    assert(locateDifference(h, 4, g, 4) == 2);
    assert(circleLeft(g, 4, 1) == 1 && g[1] == "chris" && g[3] == "ron");

    string c[4] = { "ma", "can", "tu", "do" };
    assert(reduplicate(c, 4) == 4 && c[0] == "mama" && c[3] == "dodo");

    string e[4] = { "asa", "vivek", "", "chris" };
    assert(subsequence(h, 7, e, 4) == 2);

    string d[5] = { "ron", "ron", "ron", "chris", "chris" };
    assert(enumerateRuns(d, 5) == 2);

    string f[3] = { "vivek", "asa", "tim" };
    assert(locateAny(h, 7, f, 3) == 2);
    assert(flip(f, 3) == 3 && f[0] == "tim" && f[2] == "vivek");

    assert(divide(h, 7, "donald") == 3);

    cout << "All tests succeeded" << endl;
    string test[10] = {"4","2","7","9","1","3","8", "5","6","0"};
    string test1[10] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"}; 
    int x = divide(test, 10, "5");
    int x1 = divide(test1, 10, "5");
    for(int i = 0; i < 10; i++){
	    cout << test[i] << ' ';
    }
    cout << endl << x << endl;
    for(int i = 0; i < 10; i++){
	    cout << test1[i] << ' ';
    }
    cout << endl << x1 << endl;
}

int reduplicate(string a[], int n){
	if(n < 0){
		return -1;
	}
	for(int i = 0; i < n; i++){
		a[i] = a[i]+a[i];
	}
	return n;
}
int locate(const string a[], int n, string target){
	if(n < 0){
		return -1;
	}
	for(int i = 0; i < n; i++){
		if(a[i] == target){
			return i;
		}
	}
	return -1;
}	
int locationOfMax(const string a[], int n){
	if(n <= 0){
		return -1;
	}
	string max = a[0];
	int pos = 0;
	for(int i = 1; i < n; i++){
		if(a[i] > max){
			pos = i;
			max = a[i];
		}
	}
	return pos;
}
int circleLeft(string a[], int n, int pos){
	if(n <= 0){
		return -1;
	}
	if(pos >= n){
		return -1;
	}
	string temp = a[pos];
	for(int i = pos; i < n-1; i++){
		a[i] = a[i+1];
	}
	a[n-1] = temp;
	return pos;
}
int enumerateRuns(const string a[], int n){
	if(n < 0){
		return -1;
	}
	if(n == 0){
		return 0;
	}
	int runs = 1;
	string cs = a[0];
	for(int i = 1; i < n; i++){
		if(a[i] != cs){
			cs = a[i];
			runs++;
		}
	}
	return runs;
}
int flip(string a[], int n){
	if(n < 0){
		return -1;
	}
	int halfway = n/2;
	for(int i = 0; i < halfway; i++){
		string temp = a[n-1-i];
		a[n-1-i] = a[i];
		a[i] = temp;
	}
	return n;
}
int locateDifference(const string a1[], int n1, const string a2[], int n2){
	if(n1 < 0 || n2 < 0){
		return -1;
	}
	for(int i = 0; i < n1 && i < n2; i++){
		if(a1[i] != a2[i]){
			return i;
		}
	}
	if(n1 <= n2){
		return n1;
	}
	return n2;
}
int subsequence(const string a1[], int n1, const string a2[], int n2){
	if(n1 < 0 || n2 < 0){
		return -1;
	}
	if(n2 == 0){
		return 0;
	}
	if(n1 == 0){
		return -1;
	}
	for(int i = 0; i < n1; i++){
		if(a1[i] == a2[0]){
			bool worked = true;
			for(int j = 1; j < n2; j++){
				if(!((j+i) < n1)){
					worked = false;
					break;
				}
				if(a1[j+i] != a2[j]){
					worked = false;
					break;
				}
			}
			if(worked){
				return i;
			}
		}
	}
	return -1;

}
int locateAny(const string a1[], int n1, const string a2[], int n2){
	if(n1 < 0 || n2 < 0){
		return -1;
	}
	for(int i = 0; i < n1; i++){
		for(int j = 0; j < n2; j++){
			if(a1[i] == a2[j]){
				return i;
			}
		}
	}
	return -1;
}
int divide(string a[], int n, string divider){
	if(n < 0){
		return -1;
	}
	int i = 0;
	int j = n-1;
	while(i <= j){
		if(a[i] >= divider){
			string temp = a[j];
			a[j] = a[i];
			a[i] = temp;
			j--;
		}
		else{
			i++;
		}
	}
	return i;
}

