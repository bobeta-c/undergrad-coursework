/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_106(unsigned *p)
{
    *p = 2428995912U;
}

void setval_450(unsigned *p)
{
    *p = 3281017048U;
}

unsigned getval_394()
{
    return 3284633928U;
}

unsigned getval_462()
{
    return 3281293400U;
}

unsigned getval_477()
{
    return 616716429U;
}

unsigned getval_198()
{
    return 2421705965U;
}

unsigned addval_122(unsigned x)
{
    return x + 2428996424U;
}

unsigned getval_370()
{
    return 3284633944U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_165(unsigned *p)
{
    *p = 3677933197U;
}

unsigned addval_226(unsigned x)
{
    return x + 3758704876U;
}

unsigned getval_305()
{
    return 3229926025U;
}

void setval_330(unsigned *p)
{
    *p = 2425409161U;
}

unsigned getval_239()
{
    return 2428672328U;
}

unsigned getval_286()
{
    return 3525886601U;
}

unsigned getval_417()
{
    return 3250751758U;
}

void setval_240(unsigned *p)
{
    *p = 3251538277U;
}

unsigned addval_369(unsigned x)
{
    return x + 2446231895U;
}

void setval_151(unsigned *p)
{
    *p = 2425474697U;
}

unsigned addval_194(unsigned x)
{
    return x + 2446428644U;
}

void setval_442(unsigned *p)
{
    *p = 3281044105U;
}

void setval_412(unsigned *p)
{
    *p = 2497743176U;
}

void setval_470(unsigned *p)
{
    *p = 3385119113U;
}

unsigned addval_324(unsigned x)
{
    return x + 3374371209U;
}

void setval_174(unsigned *p)
{
    *p = 3525366169U;
}

unsigned getval_456()
{
    return 2430634312U;
}

unsigned getval_280()
{
    return 3286272328U;
}

unsigned getval_413()
{
    return 2447411528U;
}

void setval_177(unsigned *p)
{
    *p = 3676885385U;
}

unsigned getval_411()
{
    return 2497743176U;
}

unsigned addval_269(unsigned x)
{
    return x + 3269495112U;
}

void setval_196(unsigned *p)
{
    *p = 3223896713U;
}

unsigned addval_473(unsigned x)
{
    return x + 3281112713U;
}

void setval_392(unsigned *p)
{
    *p = 3374370441U;
}

unsigned getval_187()
{
    return 3515473978U;
}

void setval_182(unsigned *p)
{
    *p = 3385115273U;
}

unsigned getval_114()
{
    return 2430634316U;
}

void setval_123(unsigned *p)
{
    *p = 4240560521U;
}

unsigned addval_395(unsigned x)
{
    return x + 2462222719U;
}

unsigned addval_419(unsigned x)
{
    return x + 3281047169U;
}

unsigned getval_199()
{
    return 3682914569U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
