#include "newMap.h"
#include <iostream>
#include <cassert>
using namespace std;

int main()
{
	Map m;  // maps ints to strings
	assert(m.empty());
}
